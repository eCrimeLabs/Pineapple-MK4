#!/bin/sh
#Custom Script 4

logger 4