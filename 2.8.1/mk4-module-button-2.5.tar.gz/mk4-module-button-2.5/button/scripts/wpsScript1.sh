#!/bin/sh
#Custom Script 1

logger 1