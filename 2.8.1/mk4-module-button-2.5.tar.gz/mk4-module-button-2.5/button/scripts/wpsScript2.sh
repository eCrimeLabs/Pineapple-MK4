#!/bin/sh
#Custom Script 2

logger 2