#!/bin/sh
#Custom Script 3

logger 3