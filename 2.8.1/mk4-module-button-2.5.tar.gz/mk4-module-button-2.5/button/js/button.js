function init() {
	$("#tabs ul").idTabs();
}