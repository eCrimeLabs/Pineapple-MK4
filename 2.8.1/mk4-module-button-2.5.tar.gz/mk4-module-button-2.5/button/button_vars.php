<?php

$module_name = "Button";
$module_path = exec("pwd")."/";
$module_version = "2.5";

$_wpsx_values = array("Do Nothing", "Toggle Karma", "Toggle DNS Spoof", "Toggle URL Snarf", "Connect SSH", "Reboot", "Run Custom Script 1", "Run Custom Script 2", "Run Custom Script 3", "Run Custom Script 4", "Run Default Script");
$_wpsx_time = array("0-2 Seconds", "4-6 Seconds", "8-10 Seconds", "12+ Seconds");
$_wpsx_min = array(0,4,8,12);
$_wpsx_max = array(2,6,10,30);

?>