def response(ctx, flow):
 flow.response.headers["pineapple"] = ["rocks"]