<?php

$module_name = "OPKG Manager";
$module_path = exec("pwd")."/";
$module_version = "2.3";

?>